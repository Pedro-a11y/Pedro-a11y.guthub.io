---
layout: post_bare
---

# YOUR RESUME

You can put your resume here, This file is linked on /about page

This page use `post_bare` layout, and this layout support GFM markdown

`post_bare` layout just look like this page